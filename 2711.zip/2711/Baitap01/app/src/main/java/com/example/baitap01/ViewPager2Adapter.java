package com.example.baitap01;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ViewPager2Adapter extends FragmentStateAdapter {

    public ViewPager2Adapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
        super(fragmentManager, lifecycle);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        // Tạo fragment tương ứng với từng tab
        switch (position) {
            case 0:
                return new CancelFragment();  // Tab "Xác nhận"
            case 1:
                return new DanhGiaFragment(); // Tab "Lấy hàng"
            case 2:
                return new DeliveryFragment(); // Tab "Đang giao"
            case 3:
                return new DanhGiaFragment(); // Tab "Đánh giá"
            case 4:
                return new CancelFragment();  // Tab "Hủy"
            default:
                return new CancelFragment();
        }
    }

    @Override
    public int getItemCount() {
        return 5; // Số lượng tabs
    }
}