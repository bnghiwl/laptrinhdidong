package com.example.baitap01;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.widget.ViewPager2;

import com.example.baitap01.databinding.ActivityMainBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.example.baitap01.ViewPager2Adapter;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private ViewPager2Adapter viewPager2Adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ViewBinding
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Toolbar
        setSupportActionBar(binding.toolbar);

        // FloatingActionButton
        FloatingActionButton fab = binding.fabAction;
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action",
                                Snackbar.LENGTH_LONG)
                        .setAction("Action", null)
                        .show();
            }
        });

        // ===== Thiết lập tiêu đề cho các Tab (5 tab, khớp với adapter) =====
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Xác nhận"));  // 0
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Lấy hàng"));  // 1
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Đang giao")); // 2
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Đánh giá"));  // 3
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText("Hủy"));       // 4

        // Adapter cho ViewPager2
        FragmentManager fragmentManager = getSupportFragmentManager();
        viewPager2Adapter = new ViewPager2Adapter(fragmentManager, getLifecycle());
        binding.viewPager2.setAdapter(viewPager2Adapter);

        // Chuyển tab khi click vào TabLayout
        binding.tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                binding.viewPager2.setCurrentItem(tab.getPosition());
                changeFabIcon(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });

        // Chuyển tab khi lướt ViewPager2
        binding.viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                binding.tabLayout.selectTab(binding.tabLayout.getTabAt(position));
                changeFabIcon(position);
            }
        });
    }

    // Thay đổi icon cho FloatingActionButton theo từng tab
    private void changeFabIcon(final int index) {
        binding.fabAction.hide();
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                switch (index) {
                    case 0:
                        binding.fabAction.setImageDrawable(
                                getDrawable(R.drawable.ic_baseline_chat_24));
                        break;
                    case 1:
                        binding.fabAction.setImageDrawable(
                                getDrawable(R.drawable.ic_baseline_camera_alt_24));
                        break;
                    case 2:
                        binding.fabAction.setImageDrawable(
                                getDrawable(R.drawable.ic_baseline_call_24));
                        break;
                    case 3:
                        // tab Đánh giá – tạm dùng lại icon chat
                        binding.fabAction.setImageDrawable(
                                getDrawable(R.drawable.ic_baseline_chat_24));
                        break;
                    case 4:
                        // tab Hủy – tạm dùng lại icon call
                        binding.fabAction.setImageDrawable(
                                getDrawable(R.drawable.ic_baseline_call_24));
                        break;
                    default:
                        binding.fabAction.setImageDrawable(
                                getDrawable(R.drawable.ic_baseline_chat_24));
                        break;
                }
                binding.fabAction.show();
            }
        }, 200);   // delay nhẹ cho mượt, không cần 2000ms
    }

    // Menu ở Toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menuSearch) {
            Toast.makeText(this, "Bạn đang chọn search", Toast.LENGTH_SHORT).show();

        } else if (id == R.id.menuNewGroup) {
            Toast.makeText(this, "Bạn đang chọn new group", Toast.LENGTH_SHORT).show();

        } else if (id == R.id.menuBroadcast) {
            Toast.makeText(this, "Bạn đang chọn broadcast", Toast.LENGTH_SHORT).show();

        } else if (id == R.id.menuNewCall) {
            Toast.makeText(this, "Bạn đang chọn new call", Toast.LENGTH_SHORT).show();

        } else if (id == R.id.menuMessage) {
            Toast.makeText(this, "Bạn đang chọn more", Toast.LENGTH_SHORT).show();

        } else if (id == R.id.menuSetting) {
            Toast.makeText(this, "Bạn đang chọn Setting", Toast.LENGTH_SHORT).show();
        }

        return super.onOptionsItemSelected(item);
    }
}